package Functions;

import model.User;
import service.UserService;
import validator.UserValidator;
import java.util.List;
import java.util.Scanner;

public class UsersFunctions {
    private static Scanner scanner = new Scanner(System.in);
    private static UserService userService = new UserService();
    public static User loggedUser = null;

    public static void login() {
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Senha: ");
        String password = scanner.nextLine();

        loggedUser = userService.authenticate(email, password);

        if (loggedUser != null) {
            System.out.println("Login realizado com sucesso! Bem-vindo, " + loggedUser.getName());
            UserMenu.showMenu(loggedUser);
        } else {
            System.out.println("Credenciais inválidas ou usuário inativo!");
        }
    }

    public static void logout() {
        loggedUser = null;
        System.out.println("Logout realizado com sucesso!");
    }

    public static void listUsers() {
        List<User> users = userService.getAllUsers();

        System.out.println("\n=== Listar Usuário ===\n");
        System.out.printf("| %-3s | %-20s | %-25s | %-8s | %-15s |\n", "Id", "Nome", "e-mail", "status", "Grupo");
        System.out.println("|-----|----------------------|---------------------------|----------|-----------------|");

        for (User user : users) {
            System.out.printf("| %-3d | %-20s | %-25s | %-8s | %-15s |\n",
                    user.getId(),
                    user.getName(),
                    user.getEmail(),
                    user.isActive() ? "ativo" : "inativo",
                    user.isAdmin() ? "Administrador" : "Estoquista"
            );
        }

        System.out.print("\nEntre com o id para editar/ativar/inativar, 0 para voltar e i para incluir => ");
        String input = scanner.nextLine();

        if (input.equals("0")) {
            return;
        } else if (input.equalsIgnoreCase("i")) {
            registerUser();
        } else {
            try {
                int userId = Integer.parseInt(input);
                User selectedUser = userService.getUserById(userId);

                if (selectedUser == null) {
                    System.out.println("Usuário não encontrado!");
                    return;
                }

                System.out.println("\n\t\tOpções de usuário");
                System.out.println("\nOpção de edição de usuário\n");
                System.out.println("Id: " + selectedUser.getId());
                System.out.println("Nome: " + selectedUser.getName());
                System.out.println("Cpf: xxx.xxx.xxx-xx");
                System.out.println("E-mail: " + selectedUser.getEmail());
                System.out.println("Status: " + (selectedUser.isActive() ? "ativo" : "inativo"));
                System.out.println("Grupo: " + (selectedUser.isAdmin() ? "Administrador" : "Estoquista"));
                System.out.println("--------------------------------------------------");
                System.out.println("Opções");
                System.out.println("1) Alterar usuário");
                System.out.println("2) Alterar senha");
                System.out.println("3) Ativar/Desativar");
                System.out.println("4) Voltar Listar Usuário");
                System.out.print("\nEntre com a opção (1,2,3,4) => ");

                String action = scanner.nextLine();
                switch (action) {
                    case "1":
                        editUser();
                        break;
                    case "2":
                        changeUserPassword();
                        break;
                    case "3":
                        toggleUserStatus();
                        break;
                    case "4":
                        listUsers();
                        break;
                    default:
                        System.out.println("Opção inválida!");
                }

            } catch (NumberFormatException e) {
                System.out.println("ID inválido!");
            }
        }


    }

    public static void editUser() {
//        listUsers(); // Mostra os usuários

        System.out.print("\nDigite o ID do usuário que deseja editar: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Limpa o buffer

        User user = userService.getUserById(userId);

        if (user == null) {
            System.out.println("Usuário não encontrado.");
            return;
        }

        System.out.println("\n=== Editar Usuário ===");
        System.out.println("Id: " + user.getId());
        System.out.println("Nome atual: " + user.getName());
        System.out.println("Cpf atual: " + user.getCpf());
        System.out.println("E-mail atual: " + user.getEmail());

        System.out.print("\nNovo nome => ");
        String nome = scanner.nextLine();

        System.out.print("Novo CPF => ");
        String cpf = scanner.nextLine();

        System.out.print("Novo e-mail => ");
        String email = scanner.nextLine();

        System.out.print("Salvar alteração (Y/N) => ");
        String confirmacao = scanner.nextLine();

        if (confirmacao.equalsIgnoreCase("y")) {
            user.setName(nome);
            user.setCpf(cpf);
            user.setEmail(email);

            boolean atualizado = userService.updateUser(user);
            if (atualizado) {
                System.out.println("Usuário atualizado com sucesso!");
            } else {
                System.out.println("Erro ao atualizar usuário.");
            }
        } else {
            System.out.println("Alteração cancelada.");
        }
    }



    public static void registerUser() {
        User newUser = new User();

        System.out.println("\n=== Cadastro de Usuário ===");
        System.out.print("Nome: ");
        newUser.setName(scanner.nextLine());

        String username;
        do {
            System.out.print("Username (3-20 caracteres, apenas letras, números e _): ");
            username = scanner.nextLine();
            if (!UserValidator.isValidUsername(username)) {
                System.out.println("Username inválido!");
            }
        } while (!UserValidator.isValidUsername(username));
        newUser.setUsername(username);

        String email;
        do {
            System.out.print("Email: ");
            email = scanner.nextLine();
            if (!UserValidator.isValidEmail(email)) {
                System.out.println("Email inválido!");
            }
        } while (!UserValidator.isValidEmail(email));
        newUser.setEmail(email);

        String password;
        do {
            System.out.print("Senha (mínimo 8 caracteres, letras maiúsculas, minúsculas e números): ");
            password = scanner.nextLine();
            if (!UserValidator.isValidPassword(password)) {
                System.out.println("Senha inválida!");
            }
        } while (!UserValidator.isValidPassword(password));
        newUser.setPassword(password);

        System.out.print("Administrador (S/N): ");
        String isAdmin = scanner.nextLine();
        newUser.setAdmin(isAdmin.equalsIgnoreCase("S"));

        newUser.setActive(true);

        boolean success = userService.registerUser(newUser);

        if (success) {
            System.out.println("Usuário cadastrado com sucesso!");
        } else {
            System.out.println("Erro ao cadastrar usuário. Username ou email já existem.");
        }
    }

    public static void changeUserPassword() {
        System.out.print("Digite o ID do usuário: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Limpar buffer

        // Verificar se o usuário existe
        User user = userService.getUser(userId);
        if (user == null) {
            System.out.println("Usuário não encontrado!");
            return;
        }

        // Exibir dados do usuário
        System.out.println("\n=== Dados do Usuário ===");
        System.out.println("ID: " + user.getId());
        System.out.println("Nome: " + user.getName());
        System.out.println("Username: " + user.getUsername());

        String newPassword;
        do {
            System.out.print("Digite a nova senha (mínimo 8 caracteres, letras maiúsculas, minúsculas e números): ");
            newPassword = scanner.nextLine();
            if (!UserValidator.isValidPassword(newPassword)) {
                System.out.println("Senha inválida!");
            }
        } while (!UserValidator.isValidPassword(newPassword));

        boolean success = userService.changeUserPassword(userId, newPassword);

        if (success) {
            System.out.println("Senha alterada com sucesso!");
        } else {
            System.out.println("Erro ao alterar senha. ID não encontrado.");
        }
    }



    public static void toggleUserStatus() {
        System.out.print("Digite o ID do usuário: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Limpar buffer

        // Buscar o usuário para verificar o status atual
        User user = userService.getUser(userId);

        if (user == null) {
            System.out.println("Usuário não encontrado!");
            return;
        }

        // Exibir dados do usuário
        System.out.println("\n=== Dados do Usuário ===");
        System.out.println("ID: " + user.getId());
        System.out.println("Nome: " + user.getName());
        System.out.println("Username: " + user.getUsername());
        System.out.println("Email: " + user.getEmail());
        System.out.println("Status atual: " + (user.isActive() ? "ATIVO" : "INATIVO"));

        // Mostrar opção contrária do status atual
        System.out.print("Deseja " + (user.isActive() ? "DESATIVAR" : "ATIVAR") + " este usuário? (S/N): ");
        String confirm = scanner.nextLine();

        if (confirm.equalsIgnoreCase("S")) {
            boolean success = userService.toggleUserActiveStatus(userId);

            if (success) {
                System.out.println("Status do usuário alterado com sucesso para " +
                        (!user.isActive() ? "ATIVO" : "INATIVO") + "!");
            } else {
                System.out.println("Erro ao alterar status do usuário!");
            }
        } else {
            System.out.println("Operação cancelada.");
        }
    }


    public static void changeMyPassword() {
        System.out.print("Digite sua senha atual: ");
        String currentPassword = scanner.nextLine();

        if (!loggedUser.getPassword().equals(currentPassword)) {
            System.out.println("Senha atual incorreta!");
            return;
        }

        String newPassword;
        do {
            System.out.print("Digite a nova senha (mínimo 8 caracteres, letras maiúsculas, minúsculas e números): ");
            newPassword = scanner.nextLine();
            if (!UserValidator.isValidPassword(newPassword)) {
                System.out.println("Senha inválida!");
            }
        } while (!UserValidator.isValidPassword(newPassword));

        boolean success = userService.changeUserPassword(loggedUser.getId(), newPassword);

        if (success) {
            System.out.println("Sua senha foi alterada com sucesso!");
            loggedUser.setPassword(newPassword);
        } else {
            System.out.println("Erro ao alterar sua senha.");
        }
    }

    // Métodos adicionados para facilitar testes
    public static void setUserService(UserService service) {
        userService = service;
    }

    public static void setLoggedUser(User user) {
        loggedUser = user;
    }
}

